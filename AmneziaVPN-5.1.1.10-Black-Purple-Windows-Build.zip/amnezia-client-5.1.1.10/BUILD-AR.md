# بناء AmneziaVPN 5.1.1.10 - Black/Purple على Windows

هذه نسخة مصدر معدّلة لتغيير ألوان واجهة Qt Quick/QML إلى الأسود والبنفسجي. تم الحفاظ على ملفات منطق الاتصال والخدمات كما هي؛ التغيير الأساسي في `client/ui/qml/Modules/Style/AmneziaStyle.qml`.

## المتطلبات

1. Windows 10/11 بنظام 64-bit.
2. Visual Studio 2022 أو Visual Studio 2022 Build Tools مع Desktop development with C++.
3. CMake.
4. Qt 6.10 أو أحدث، مع حزمة MSVC 2022 64-bit، ووحدات Qt Core وQt Remote Objects وQt 5 Compatibility.
5. Conan 2 مثبت ومتاح من PATH.
6. اتصال إنترنت في أول بناء لتنزيل الاعتماديات التي يديرها Conan.

## طريقة البناء

1. فك ضغط مجلد المشروع بالكامل.
2. افتح Command Prompt أو PowerShell.
3. ادخل إلى مجلد `amnezia-client-5.1.1.10`.
4. شغّل:

   ```bat
   BUILD-WINDOWS.bat
   ```

5. انتظر انتهاء CMake وConan وVisual Studio. أول بناء قد يستغرق وقتًا طويلًا.
6. الملفات الناتجة ستكون داخل مجلد `deploy\build`؛ مسار ملف التشغيل النهائي قد يختلف حسب إعدادات CMake.

لبناء مُثبّت Windows باستخدام Qt Installer Framework وWiX (بعد تثبيت الأدوات المطلوبة):

```bat
BUILD-WINDOWS.bat --installer all
```

## تخصيص مسار Qt

إذا لم يكتشف السكربت Qt تلقائيًا، عيّن `QT_ROOT_PATH` إلى مجلد تثبيت Qt الذي يحتوي على مجلد `msvc2022_64`، مثل:

```bat
set QT_ROOT_PATH=C:\Qt\6.10.0
BUILD-WINDOWS.bat
```

## ملاحظات مهمة

- هذا **سورس كود** وليس ملف EXE جاهزًا.
- لا يمكن إنتاج ملف Windows EXE من بيئة Linux الحالية؛ يجب تنفيذ البناء على Windows مع المتطلبات أعلاه أو توفير بيئة Windows build مناسبة.
- لم يتم تنفيذ بناء Windows أو اختبار البرنامج الناتج في هذه الجلسة.
- لا تحذف مجلد `deploy`, أو `recipes`, أو `client/3rd`؛ فهي أجزاء مطلوبة للبناء.
