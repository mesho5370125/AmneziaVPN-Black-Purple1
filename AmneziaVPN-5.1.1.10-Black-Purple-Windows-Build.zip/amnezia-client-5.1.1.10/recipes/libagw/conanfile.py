from conan import ConanFile
from conan.tools.files import copy, chdir, get
from conan.tools.layout import basic_layout
from conan.errors import ConanInvalidConfiguration
from conan.tools.gnu import AutotoolsToolchain
from conan.tools.apple import XCRun, is_apple_os
from conan.tools.apple.apple import _to_apple_arch
from conan.tools.env import Environment

import os
import shlex


class Libagw(ConanFile):
    name = "libagw"
    version = "1.0.8"
    settings = "os", "arch", "compiler"

    _headers = ("agw.h", "agw_types.h")
    _static_lib = "libagw.a"
    _shared_lib = "libagw.so"
    _dll = "agw.dll"
    _def_file = "agw.def"
    _import_lib = "agw.lib"
    _slices_dir = "slices"

    _arch_map = {
        "x86": "386",
        "x86_64": "amd64",
        "armv7": "arm",
        "armv8": "arm64"
    }

    @property
    def _goos(self):
        return {
            "Linux": "linux",
            "Android": "android",
            "iOS": "ios",
            "Macos": "darwin",
            "Windows": "windows"
        }.get(str(self.settings.os))

    @property
    def _archs(self):
        return str(self.settings.arch).split("|")

    @property
    def _is_multiarch(self):
        return len(self._archs) > 1

    @property
    def _is_windows(self):
        return str(self.settings.os).startswith("Windows")

    @property
    def _is_android(self):
        return str(self.settings.os) == "Android"

    def config_options(self):
        shared = self._is_windows or self._is_android
        self.package_type = "shared-library" if shared else "static-library"

    def configure(self):
        self.settings.rm_safe("compiler.libcxx")
        self.settings.rm_safe("compiler.cppstd")
        if self._is_windows:
            del self.settings.compiler

    def layout(self):
        basic_layout(self)

    def build_requirements(self):
        self.tool_requires("go/1.27.1")
        if self._is_windows:
            self.win_bash = True
            if not self.conf.get("tools.microsoft.bash:path", check_type=str):
                self.tool_requires("msys2/cci.latest")
            self.tool_requires("mingw-builds/15.1.0")

    def validate(self):
        if not self._goos or not all(arch in self._arch_map for arch in self._archs):
            raise ConanInvalidConfiguration(
                f"{self.name} v{self.version} does not support {self.settings.os} {self.settings.arch}"
            )

        if self._is_multiarch and not is_apple_os(self):
            raise ConanInvalidConfiguration(
                f"{self.name} v{self.version} does not support multiarch builds"
            )

    def source(self):
        get(self, f"https://github.com/amnezia-vpn/libagw/archive/refs/tags/v{self.version}.zip",
            sha256="ad36125be7ff4a77603107a0bc2194da6778d5612e649f53c9d954c742bb70db", strip_root=True
        )

    def generate(self):
        tc = AutotoolsToolchain(self)
        tc.apple_arch_flag = None
        env = tc.environment()
        env.define("GOPATH", os.path.join(self.build_folder, "gopath"))
        env.define("GOMODCACHE", os.path.join(self.build_folder, "gopath", "pkg", "mod"))
        env.define("GOCACHE", os.path.join(self.build_folder, "gocache"))
        env.define("GOOS", self._goos)
        env.define("CGO_ENABLED", "1")
        self._ldflags = tc.ldflags
        self._cflags = tc.cflags
        tc.generate(env)

    def _go_build(self, output, buildmode, goarch, cflags, ldflags, goldflags=""):
        env = Environment()
        env.define("GOARCH", goarch)
        env.define("CGO_CFLAGS", " ".join(cflags))
        env.define("CGO_LDFLAGS", " ".join(ldflags))
        go_ldflags = " ".join(filter(None, ["-s -w", goldflags]))
        with env.vars(self).apply():
            self.run(f'go build -buildmode={buildmode} -ldflags="{go_ldflags}" '
                     f'-o {shlex.quote(output)} ./archive')

    def build(self):
        with chdir(self, self.source_folder):
            for arch in self._archs:
                build_dir = os.path.join(self.build_folder, self._slices_dir, arch) if self._is_multiarch else self.build_folder
                if self._is_windows:
                    build_dir = build_dir.replace("\\", "/")
                goarch = self._arch_map.get(arch)

                cflags = list(self._cflags)
                ldflags = list(self._ldflags)
                if is_apple_os(self):
                    cflags.append(f"-arch {_to_apple_arch(arch)}")
                    ldflags.append(f"-arch {_to_apple_arch(arch)}")

                if self._is_windows:
                    self._go_build(f"{build_dir}/{self._dll}", "c-shared", goarch, cflags, ldflags)
                    with chdir(self, build_dir):
                        self.run(f"gendef {self._dll}")
                        self.run(f"dlltool -d {self._def_file} -l {self._import_lib} -D {self._dll}")
                elif self._is_android:
                    self._go_build(os.path.join(build_dir, self._shared_lib), "c-shared", goarch, cflags, ldflags,
                                   goldflags=f"-extldflags=-Wl,-soname,{self._shared_lib}")
                else:
                    goldflags = "-X=runtime.godebugDefault=asyncpreemptoff=1" if is_apple_os(self) else ""
                    self._go_build(os.path.join(build_dir, self._static_lib), "c-archive", goarch, cflags, ldflags,
                                   goldflags=goldflags)

            if is_apple_os(self) and self._is_multiarch:
                lipo = XCRun(self).find("lipo")
                archives = [os.path.join(self.build_folder, self._slices_dir, arch, self._static_lib)
                            for arch in self._archs]
                output = os.path.join(self.build_folder, self._static_lib)
                self.run("{} -create -output {} {}".format(
                    shlex.quote(lipo),
                    shlex.quote(output),
                    shlex.join(archives)
                ))

    def package(self):
        headers = os.path.join(self.source_folder, "cabi")
        include_dir = os.path.join(self.package_folder, "include")
        lib_dir = os.path.join(self.package_folder, "lib")
        bin_dir = os.path.join(self.package_folder, "bin")
        for header in self._headers:
            copy(self, header, src=headers, dst=include_dir, keep_path=False)
        copy(self, self._static_lib, src=self.build_folder, dst=lib_dir, keep_path=False,
             excludes=[f"{self._slices_dir}/*"])
        copy(self, self._shared_lib, src=self.build_folder, dst=lib_dir, keep_path=False)
        copy(self, self._import_lib, src=self.build_folder, dst=lib_dir, keep_path=False)
        copy(self, self._dll, src=self.build_folder, dst=bin_dir, keep_path=False)

    def package_info(self):
        self.cpp_info.set_property("cmake_target_name", "amnezia::libagw")
        self.cpp_info.libs = ["agw"]
        if is_apple_os(self):
            self.cpp_info.frameworks = ["CoreFoundation", "Security"]
        elif self._is_android:
            self.cpp_info.system_libs = ["log"]
        elif str(self.settings.os) == "Linux":
            self.cpp_info.system_libs = ["pthread"]
