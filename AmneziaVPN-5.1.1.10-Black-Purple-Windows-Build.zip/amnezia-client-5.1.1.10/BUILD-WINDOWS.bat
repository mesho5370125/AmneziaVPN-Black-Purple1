@echo off
setlocal
cd /d "%~dp0"

echo ================================================
echo AmneziaVPN 5.1.1.10 - Black/Purple Windows Build
echo ================================================
echo.

where cmake >nul 2>nul || (echo [ERROR] CMake is missing from PATH. & exit /b 1)
where conan >nul 2>nul || (echo [ERROR] Conan is missing from PATH. Install Conan 2 and reopen the terminal. & exit /b 1)

if not defined VCINSTALLDIR (
  echo [INFO] Visual Studio environment not detected.
  echo [INFO] The project build script will try to locate Visual Studio 2022 automatically.
)

if not defined QT_ROOT_PATH (
  echo [INFO] QT_ROOT_PATH is not set. The project build script will search common Qt install folders.
  echo [INFO] Required Qt kit: Qt 6.10+ MSVC 2022 64-bit, including Qt Remote Objects and Qt 5 Compatibility.
)

echo.
echo Starting Windows build. This may take a while on the first run.
echo.
call "%~dp0deploy\build.bat" %*
if errorlevel 1 (
  echo.
  echo [ERROR] Build failed. Check the messages above and the prerequisites in BUILD-AR.md.
  exit /b 1
)

echo.
echo [SUCCESS] Build completed. Check the deploy\build folder for generated files.
exit /b 0
